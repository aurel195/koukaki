
<div class="clouds">
    <img class="big-cloud" src="<?php echo get_theme_file_uri() . '/assets/images/big_cloud.png'; ?> " alt="Grand nuage"> 
    <img class="little-cloud" src="<?php echo get_theme_file_uri() . '/assets/images/little_cloud.png'; ?> " alt="Petit nuage"> 
</div>