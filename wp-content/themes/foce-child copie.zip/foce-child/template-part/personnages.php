<div class="swiper mySwiper">
    <div class="swiper-wrapper">
        <div class="swiper-slide">
            <img src="<?php echo get_theme_file_uri() .'/assets/images/Kawaneko.png';?>" alt="Kawaneko">
            <h4>Kawaneko</h4>
        </div>
        <div class="swiper-slide">
            <img src="<?php echo get_theme_file_uri() .'/assets/images/Onejiiro.png';?>" alt="Onejiiro">
            <h4>Onejiiro</h4>
        </div>
        <div class="swiper-slide">
            <img src="<?php echo get_theme_file_uri() .'/assets/images/Pinku.png';?>" alt="Pinku">
            <h4>Pinku</h4>
        </div>
        <div class="swiper-slide">
            <img src="<?php echo get_theme_file_uri() .'/assets/images/Tenshi.png';?>" alt="Tenshi">
            <h4>Tenshi</h4>
        </div>
        <div class="swiper-slide">
            <img src="<?php echo get_theme_file_uri() .'/assets/images/Jaakuna.png';?>" alt="Jaakuna">
            <h4>Jaakuna</h4>
        </div>
    </div>
</div>
