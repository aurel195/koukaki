<section id="nomination" class="nomination fadeUp">
    <div class="sunflower_section_nomination">
        <img src="<?php echo get_theme_file_uri ("./assets/images/Sunflower.png"); ?>" alt="Sunflower">
    </div>
    <div class="orchidee_section_nomination">
        <img src="<?php echo get_theme_file_uri ("./assets/images/orchid.png"); ?>" alt="Orchid">
    </div>
    <h3 class="animTitle">Fleurs d'oranger & chats errants est nominé aux Oscars Short Film Animated de 2022 !</h3>
    <img class="oscars_logo" src="<?php echo get_theme_file_uri ("./assets/images/logoOscars.png"); ?> " alt="logo nomination des oscars">
</section>



