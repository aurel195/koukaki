<img class="logo parallax" src="<?php echo get_theme_file_uri("./assets/images/logo.png"); ?> " alt="logo Fleurs d'oranger & chats errants">
<div class="image-fallback">
    <video id="video-banner" autoplay loop muted>
<source src="<?php echo get_theme_file_uri("./assets/video/header.mp4"); ?> " type="video/mp4">
</video>
</div>

